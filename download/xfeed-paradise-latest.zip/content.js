// XFeed Paradise - Content Script
// Monitors X/Twitter feed, extracts tweets, and filters based on vibe score
// Now with AI-powered sentiment analysis!

(async function() {
  'use strict';

  // Feature flag - check if Twitter support is enabled (defaults to ON)
  const TWITTER_ENABLED_KEY = 'xfp_twitter_enabled';

  const flagResult = await chrome.storage.sync.get(TWITTER_ENABLED_KEY);
  const isEnabled = flagResult[TWITTER_ENABLED_KEY] !== false; // Default to true

  if (!isEnabled) {
    console.log('🌴 XFeed Paradise: Twitter/X support is disabled.');
    return;
  }

  console.log('🌴 XFeed Paradise: Initializing...');

  // Wait for dependencies
  await window.tweetDB.ready;
  await VibeFilter.loadSettings();
  await VibeFilter.loadProviderConfig();

  // AI scoring state - the configured provider(s) score via the background worker
  let aiProviderReady = VibeFilter.provider.configured;

  // Re-read provider configuration (primary + fallback)
  async function checkProviderStatus() {
    await VibeFilter.loadProviderConfig();
    aiProviderReady = VibeFilter.provider.configured;
    return aiProviderReady;
  }

  // Initialize AI (just checks provider configuration)
  async function initAIScorer() {
    await checkProviderStatus();
    const { primaryName, fallbackName } = VibeFilter.provider;
    if (aiProviderReady) {
      console.log(`🌴 XFeed Paradise: ${primaryName} configured${fallbackName ? ` (fallback: ${fallbackName})` : ''}; connection not yet verified`);
    } else {
      console.log(`🌴 XFeed Paradise: No ${primaryName} key - using keyword scoring`);
    }
    updateFloatingPanel();
  }

  // Popup changes to provider, key or model apply without a reload
  VibeFilter.watchProviderConfig(() => {
    aiProviderReady = VibeFilter.provider.configured;
    updateFloatingPanel();
  });

  // Local AI scorer is disabled - provider scoring happens in filter.js
  window.AIScorer = {
    get isReady() { return false; }, // Local AI disabled
    scoreTweet: async () => null
  };
  VibeFilter.aiScorer = window.AIScorer;

  // Check provider status on init
  if (VibeFilter.settings.useAI !== false) {
    initAIScorer();
  }

  // Track processed tweets to avoid duplicates
  const processedTweets = new Set();

  // Track hidden tweets with their info
  let hiddenCount = 0;
  const hiddenTweets = []; // Array of { id, text, author, score, url }

  // Toast notification system
  let toastTimeout = null;
  function showToast(message, type = 'info', duration = 4000) {
    // Remove existing toast
    document.querySelector('.xfp-toast')?.remove();
    if (toastTimeout) clearTimeout(toastTimeout);

    const toast = document.createElement('div');
    toast.className = `xfp-toast ${type}`;

    const icon = type === 'warning' ? '⚠️' : type === 'error' ? '❌' : '🌴';
    toast.innerHTML = `<span class="xfp-toast-icon">${icon}</span><span>${message}</span>`;

    document.body.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
      toast.classList.add('show');
    });

    // Auto-hide
    toastTimeout = setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  // Hook into VibeFilter for rate limit notifications (debounced to prevent spam)
  let lastRateLimitToast = 0;
  VibeFilter.onRateLimit = (apiName, waitSeconds, usingName) => {
    const now = Date.now();
    // Only show toast if it's been at least 30 seconds since last one
    if (now - lastRateLimitToast > 30000) {
      lastRateLimitToast = now;
      const using = usingName ? `Using fallback ${usingName}` : 'Using keyword scoring';
      showToast(`${apiName} rate limited. ${using} for ${waitSeconds}s`, 'warning', 5000);
    }
  };

  let lastApiErrorToast = 0;
  VibeFilter.onApiError = (apiName, reason, usingName) => {
    // Built-in provider used up for today: one friendly notice (the worker
    // reports it once, then backs off until the next UTC day).
    if (reason === 'daily_limit' || reason === 'global_budget') {
      showToast(XFPProviders.BUILTIN_LIMIT_NOTICE, 'info', 8000);
      return;
    }
    const now = Date.now();
    if (now - lastApiErrorToast < 30000) return;
    lastApiErrorToast = now;
    const problem = reason === 401 || reason === 403 ? 'key rejected'
      : reason === 'network_error' ? 'connection failed'
      : reason === 'invalid_response' ? 'unexpected response'
      : reason === 'model_error' ? 'model unavailable'
      : reason === 'permission_needed' ? 'access not granted'
      : `error ${reason}`;
    const using = usingName ? `Using fallback ${usingName}` : 'Using keyword scoring';
    showToast(`${apiName} ${problem}. ${using}; check the extension popup.`, 'warning', 6000);
  };

  // IntersectionObserver for viewport detection - catches fast scrolling & recycled elements
  const viewportObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        const article = entry.target;
        // Process if not already done
        if (!article.dataset.xfpProcessed) {
          processTweet(article);
        }
      }
    }
  }, {
    root: null, // viewport
    rootMargin: '200px', // pre-process 200px before entering viewport
    threshold: 0
  });

  // Get current user's handle (feed owner)
  function getFeedOwner() {
    // Try to get from the page
    const accountSwitcher = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
    if (accountSwitcher) {
      const spans = accountSwitcher.querySelectorAll('span');
      for (const span of spans) {
        if (span.textContent.startsWith('@')) {
          return span.textContent.slice(1);
        }
      }
    }
    return 'unknown';
  }

  // Extract tweet data from a tweet element
  function extractTweetData(tweetElement) {
    try {
      // Get tweet article
      const article = tweetElement.closest('article[data-testid="tweet"]');
      if (!article) return null;

      // Extract tweet ID from link
      const tweetLink = article.querySelector('a[href*="/status/"]');
      const tweetId = tweetLink?.href?.match(/status\/(\d+)/)?.[1];
      if (!tweetId) return null;

      // Extract author info
      const authorLink = article.querySelector('a[href^="/"][role="link"]:not([href*="/status/"])');
      const authorHandle = authorLink?.href?.split('/').pop() || 'unknown';

      const displayNameEl = article.querySelector('[data-testid="User-Name"]');
      const displayName = displayNameEl?.querySelector('span')?.textContent || authorHandle;

      // Get author avatar
      const avatarImg = article.querySelector('img[src*="profile_images"]');
      const avatarUrl = avatarImg?.src || '';

      // Extract tweet text
      const tweetTextEl = article.querySelector('[data-testid="tweetText"]');
      const tweetText = tweetTextEl?.textContent || '';

      // Extract timestamp
      const timeEl = article.querySelector('time');
      const timestamp = timeEl?.dateTime ? new Date(timeEl.dateTime).getTime() : Date.now();

      // Extract engagement metrics
      const getMetric = (testId) => {
        const el = article.querySelector(`[data-testid="${testId}"]`);
        const text = el?.textContent || '0';
        return parseInt(text.replace(/[^0-9]/g, '')) || 0;
      };

      const replyCount = getMetric('reply');
      const retweetCount = getMetric('retweet');
      const likeCount = getMetric('like');

      // Check for media
      const hasImage = !!article.querySelector('[data-testid="tweetPhoto"]');
      const hasVideo = !!article.querySelector('[data-testid="videoPlayer"]');
      const hasQuote = !!article.querySelector('[data-testid="quoteTweet"]');

      // Check if it's a retweet
      const isRetweet = !!article.querySelector('[data-testid="socialContext"]')?.textContent?.includes('reposted');

      // Build tweet object
      const tweet = {
        id: tweetId,
        source: 'twitter', // Identify source for database filtering
        text: tweetText,
        authorId: authorHandle,
        authorName: displayName,
        authorAvatar: avatarUrl,
        timestamp,
        feedOwner: getFeedOwner(),
        metrics: {
          replies: replyCount,
          retweets: retweetCount,
          likes: likeCount
        },
        media: {
          hasImage,
          hasVideo,
          hasQuote
        },
        isRetweet,
        url: `https://x.com/${authorHandle}/status/${tweetId}`,
        collectedAt: Date.now()
      };

      return tweet;
    } catch (error) {
      console.error('XFeed Paradise: Error extracting tweet:', error);
      return null;
    }
  }

  // Check if we're on a tweet detail page
  function isOnTweetDetailPage() {
    return /\/status\/\d+/.test(window.location.pathname);
  }

  // Get the tweet ID from the current URL (if on detail page)
  function getTweetIdFromUrl() {
    const match = window.location.pathname.match(/\/status\/(\d+)/);
    return match ? match[1] : null;
  }

  // Apply filter to a tweet element
  function applyFilter(article, tweet, score) {
    if (!VibeFilter.settings.enabled) return;

    const shouldShow = VibeFilter.shouldShow(score);
    const vibeLabel = VibeFilter.getVibeLabel(score);

    // Don't hide the main tweet if user navigated directly to it
    const urlTweetId = getTweetIdFromUrl();
    if (urlTweetId) {
      // Check if this is the main tweet by ID match OR by being the first tweet on page
      const allTweets = document.querySelectorAll('article[data-testid="tweet"]');
      const isFirstTweet = allTweets[0] === article;
      const isIdMatch = tweet.id === urlTweetId;

      if (isIdMatch || isFirstTweet) {
        // Still show the score badge, but never hide
        if (VibeFilter.settings.showScores) {
          article.querySelector('.xfp-vibe-indicator')?.remove();
          const indicator = document.createElement('div');
          indicator.className = `xfp-vibe-indicator ${vibeLabel.class}`;
          indicator.innerHTML = `${vibeLabel.label} (${score})`;
          article.style.position = 'relative';
          article.prepend(indicator);
        }
        return; // Don't apply any hiding/dimming
      }
    }

    // Remove any existing vibe indicators
    article.querySelector('.xfp-vibe-indicator')?.remove();

    // Add score indicator if enabled
    if (VibeFilter.settings.showScores) {
      const indicator = document.createElement('div');
      indicator.className = `xfp-vibe-indicator ${vibeLabel.class}`;
      indicator.innerHTML = `${vibeLabel.label} (${score})`;
      article.style.position = 'relative';
      article.prepend(indicator);
    }

    // Apply filter mode
    if (!shouldShow) {
      const container = article.closest('[data-testid="cellInnerDiv"]');
      const wasAlreadyHidden = container?.classList.contains('xfp-hidden') ||
                               container?.classList.contains('xfp-dimmed') ||
                               container?.classList.contains('xfp-labeled');

      switch (VibeFilter.settings.filterMode) {
        case 'hide':
          container?.classList.add('xfp-hidden');
          break;
        case 'dim':
          container?.classList.add('xfp-dimmed');
          break;
        case 'label':
          container?.classList.add('xfp-labeled');
          if (!article.querySelector('.xfp-warning-label')) {
            const warning = document.createElement('div');
            warning.className = 'xfp-warning-label';
            warning.innerHTML = `
              <span>🌴 Hidden by XFeed Paradise: ${vibeLabel.label}</span>
              <button class="xfp-show-anyway">Show anyway</button>
            `;
            warning.querySelector('.xfp-show-anyway').addEventListener('click', (e) => {
              e.stopPropagation();
              article.closest('[data-testid="cellInnerDiv"]')?.classList.remove('xfp-labeled');
              warning.remove();
              hiddenCount = Math.max(0, hiddenCount - 1);
            });
            article.prepend(warning);
          }
          break;
      }

      // Track hidden tweet info if newly hidden
      if (!wasAlreadyHidden) {
        hiddenCount++;
        hiddenTweets.unshift({
          id: tweet.id,
          text: tweet.text?.slice(0, 100) + (tweet.text?.length > 100 ? '...' : ''),
          author: tweet.authorName || tweet.authorId,
          authorHandle: tweet.authorId,
          score: score,
          url: tweet.url,
          vibeLabel: vibeLabel.label
        });
        // Keep only last 50 hidden tweets
        if (hiddenTweets.length > 50) {
          hiddenTweets.pop();
        }
      }
    } else {
      // Ensure shown tweets are visible
      const container = article.closest('[data-testid="cellInnerDiv"]');
      container?.classList.remove('xfp-hidden', 'xfp-dimmed', 'xfp-labeled');
    }
  }

  // Process a single tweet element - FAST, non-blocking
  function processTweet(tweetElement) {
    const article = tweetElement.closest('article[data-testid="tweet"]');
    if (!article) return;

    // Check if this DOM element already has our marker
    if (article.dataset.xfpProcessed) {
      return; // Already processed this exact DOM element
    }

    const tweet = extractTweetData(tweetElement);
    if (!tweet) return;

    // Mark this DOM element as processed
    article.dataset.xfpProcessed = 'true';

    // Also track by ID (for stats)
    processedTweets.add(tweet.id);

    // Get score with AI refinement callback
    const { score, source } = VibeFilter.getScoreWithRefinement(
      tweet.id,
      tweet.text,
      // Callback when AI score arrives - update the filter
      (aiScore, aiSource) => {
        if (article && article.isConnected) {
          tweet.vibeScore = aiScore;
          tweet.scoredWithAI = aiSource === 'ai';
          applyFilter(article, tweet, aiScore);
          updateFloatingPanel();

          // Update in database
          const tweetWithAI = { ...tweet, vibeScore: aiScore, scoredWithAI: aiSource === 'ai' };
          window.tweetDB.saveTweet(tweetWithAI).catch(() => {});
        }
      }
    );

    tweet.vibeScore = score;
    tweet.scoredWithAI = source === 'ai';

    // Apply filter immediately with initial score
    applyFilter(article, tweet, score);

    // Save to database (non-blocking)
    window.tweetDB.saveTweet(tweet).catch(error => {
      console.error('XFeed Paradise: Error saving tweet:', error);
    });
  }

  // Process all visible tweets - non-blocking, fires all at once
  // Register a tweet with the viewport observer and process if visible
  function registerTweet(article) {
    if (!article || article.dataset.xfpObserved) return;
    article.dataset.xfpObserved = 'true';
    viewportObserver.observe(article);
    // Also try to process immediately (in case already in viewport)
    if (!article.dataset.xfpProcessed) {
      processTweet(article);
    }
  }

  function processVisibleTweets() {
    const tweets = document.querySelectorAll('article[data-testid="tweet"]');
    tweets.forEach(tweet => registerTweet(tweet));
  }

  // Observe DOM for new tweets
  function observeTweets() {
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check if the added node contains tweets
            const tweets = node.querySelectorAll?.('article[data-testid="tweet"]') || [];
            tweets.forEach(tweet => registerTweet(tweet));

            // Also check if the node itself is a tweet
            if (node.matches?.('article[data-testid="tweet"]')) {
              registerTweet(node);
            }
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    return observer;
  }

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'UPDATE_SETTINGS') {
      VibeFilter.settings = { ...VibeFilter.settings, ...message.settings };
      // Reprocess visible tweets with new settings
      reprocessVisibleTweets();
      sendResponse({ success: true });
    } else if (message.type === 'CLEAR_DATA') {
      // Clear IndexedDB and reset local state
      window.tweetDB.clearAll().then(() => {
        processedTweets.clear();
        hiddenCount = 0;
        hiddenTweets.length = 0;
        updateFloatingPanel();
        sendResponse({ success: true });
      }).catch(error => {
        console.error('XFeed Paradise: Error clearing data:', error);
        sendResponse({ success: false, error: error.message });
      });
      return true; // Keep channel open for async response
    } else if (message.type === 'GET_STATS') {
      window.tweetDB.getStats().then(stats => {
        sendResponse({
          stats,
          processedCount: processedTweets.size,
          hiddenCount,
          hiddenTweets: hiddenTweets.slice(0, 20) // Return up to 20 for popup
        });
      });
      return true; // Keep channel open for async response
    } else if (message.type === 'GET_AI_STATUS') {
      sendResponse({
        aiReady: aiProviderReady,
        aiLoading: !aiProviderReady && VibeFilter.settings.useAI,
        provider: VibeFilter.provider.primary,
        aiProgress: 100
      });
    } else if (message.type === 'TOGGLE_ENABLED') {
      VibeFilter.settings.enabled = message.enabled;
      reprocessVisibleTweets();
      sendResponse({ success: true });
    } else if (message.type === 'UPDATE_FLOATING_VISIBILITY') {
      const panel = document.querySelector('.xfp-floating-panel');
      if (panel) {
        if (message.visible) {
          panel.classList.remove('hidden');
        } else {
          panel.classList.add('hidden');
        }
        VibeFilter.settings.floatingHidden = !message.visible;
      }
      sendResponse({ success: true });
    } else if (message.type === 'UPDATE_PROVIDER' || message.type === 'UPDATE_GROQ_API_KEY') {
      // Provider, key or model changed in the popup
      checkProviderStatus().then(() => updateFloatingPanel());
      sendResponse({ success: true });
    } else if (message.type === 'UPDATE_CUSTOM_PROMPT') {
      // Update Custom Prompt
      VibeFilter.customPrompt = message.prompt || null;
      console.log('🌴 XFeed Paradise: Custom prompt updated');
      sendResponse({ success: true });
    } else if (message.type === 'GET_DEFAULT_PROMPT') {
      sendResponse({ defaultPrompt: VibeFilter.defaultPrompt });
    } else if (message.type === 'UPDATE_LOAD_MORE_VISIBILITY') {
      const container = document.querySelector('.xfp-load-more-container');
      if (container) {
        if (message.visible) {
          container.classList.remove('hidden');
        } else {
          container.classList.add('hidden');
        }
        VibeFilter.settings.hideLoadMoreButton = !message.visible;
      }
      sendResponse({ success: true });
    }
    return true;
  });

  // Reprocess all visible tweets (after settings change)
  function reprocessVisibleTweets() {
    const containers = document.querySelectorAll('[data-testid="cellInnerDiv"]');
    containers.forEach(container => {
      container.classList.remove('xfp-hidden', 'xfp-dimmed', 'xfp-labeled', 'xfp-revealed');
      container.querySelector('.xfp-vibe-indicator')?.remove();
      container.querySelector('.xfp-warning-label')?.remove();
      // Let processTweet/registerTweet run again for this post.
      const article = container.querySelector('article[data-testid="tweet"]');
      if (article) {
        delete article.dataset.xfpProcessed;
        delete article.dataset.xfpObserved;
      }
    });

    // Reset counts and reprocess
    processedTweets.clear();
    hiddenCount = 0;
    hiddenTweets.length = 0;
    processVisibleTweets();
  }

  // Create floating panel UI
  function createFloatingPanel() {
    // Remove existing panel if any
    document.querySelector('.xfp-floating-panel')?.remove();

    // Get saved position
    const position = VibeFilter.settings.floatingPosition || 'bottom-right';
    const isHidden = VibeFilter.settings.floatingHidden || false;

    const panel = document.createElement('div');
    panel.className = `xfp-floating-panel pos-${position}`;
    if (isHidden) panel.classList.add('hidden');

    panel.innerHTML = `
      <div class="xfp-floating-dropdown">
        <div class="xfp-dropdown-header">
          <span class="xfp-dropdown-title">🌴 XFeed Paradise</span>
          <button class="xfp-dropdown-close">&times;</button>
        </div>

        <!-- Hidden Tweets Section (collapsible) -->
        <div class="xfp-section">
          <button class="xfp-section-toggle xfp-hidden-toggle expanded">
            <span>Hidden Tweets <span class="xfp-hidden-count-label">(0)</span></span>
            <span class="xfp-toggle-icon">▼</span>
          </button>
          <div class="xfp-section-content xfp-hidden-content show">
            <div class="xfp-dropdown-list">
              <div class="xfp-dropdown-empty">No tweets hidden yet</div>
            </div>
          </div>
        </div>

        <!-- All Settings Section (collapsible) -->
        <div class="xfp-section">
          <button class="xfp-section-toggle xfp-settings-toggle">
            <span>Settings & Stats</span>
            <span class="xfp-toggle-icon">▼</span>
          </button>
          <div class="xfp-section-content xfp-settings-content">
            <!-- Filter Active -->
            <div class="xfp-setting-row">
              <label class="xfp-checkbox-row">
                <input type="checkbox" class="xfp-filter-active-cb" checked>
                <span>Filter Active</span>
              </label>
            </div>

            <!-- Filter Mode -->
            <div class="xfp-setting-row">
              <label class="xfp-setting-label">Filter Mode</label>
              <div class="xfp-setting-options xfp-filter-modes">
                <button class="xfp-setting-btn" data-mode="hide">Hide</button>
                <button class="xfp-setting-btn" data-mode="dim">Dim</button>
                <button class="xfp-setting-btn" data-mode="label">Collapse</button>
              </div>
            </div>

            <!-- Threshold -->
            <div class="xfp-setting-row">
              <label class="xfp-setting-label">Vibe Threshold</label>
              <div class="xfp-slider-row">
                <input type="range" class="xfp-slider xfp-threshold-slider" min="-50" max="50" value="0">
                <span class="xfp-slider-value xfp-threshold-value">0</span>
              </div>
            </div>

            <!-- Show Scores -->
            <div class="xfp-setting-row">
              <label class="xfp-checkbox-row">
                <input type="checkbox" class="xfp-show-scores-cb">
                <span>Show vibe scores on tweets</span>
              </label>
            </div>

            <div class="xfp-divider"></div>

            <!-- AI Scoring Section -->
            <div class="xfp-setting-row">
              <label class="xfp-setting-label">AI Scoring</label>
            </div>

            <!-- AI Status -->
            <div class="xfp-setting-row xfp-ai-status-row">
              <div class="xfp-ai-status-inline">
                <span class="xfp-ai-dot"></span>
                <span class="xfp-ai-text">Checking AI…</span>
              </div>
            </div>

            <!-- Use AI Toggle -->
            <div class="xfp-setting-row">
              <label class="xfp-checkbox-row">
                <input type="checkbox" class="xfp-use-ai-cb" checked>
                <span>Use AI-powered scoring</span>
              </label>
            </div>

            <!-- API Key Section (always visible) -->
            <div class="xfp-api-key-section">
              <label class="xfp-setting-label"><span class="xfp-api-key-name">API Key</span> <a class="xfp-api-key-link" href="https://console.groq.com/keys" target="_blank" rel="noopener" style="color: #60a5fa; text-decoration: none; font-size: 10px;">Get key</a></label>
              <div class="xfp-api-input-row">
                <input type="password" class="xfp-api-input" placeholder="API key">
                <button class="xfp-api-toggle-btn">Show</button>
              </div>
              <div class="xfp-api-status">Choose a provider in the extension popup</div>
            </div>

            <!-- Custom Prompt Section (always visible) -->
            <div class="xfp-prompt-section">
              <label class="xfp-setting-label">Custom Prompt (Optional)</label>
              <textarea class="xfp-prompt-input" placeholder="Rate the sentiment/vibe of this tweet from -100 (very negative, toxic, outrage-bait) to +100 (very positive, uplifting, enlightening)."></textarea>
              <div class="xfp-prompt-hint">Leave empty to use default. Must ask for a number -100 to 100.</div>
            </div>

            <div class="xfp-divider"></div>

            <!-- Stats -->
            <div class="xfp-setting-row xfp-stats-row">
              <div class="xfp-stat-item">
                <span class="xfp-stat-value xfp-stat-hidden">0</span>
                <span class="xfp-stat-label">Hidden</span>
              </div>
              <div class="xfp-stat-item">
                <span class="xfp-stat-value xfp-stat-processed">0</span>
                <span class="xfp-stat-label">Processed</span>
              </div>
              <div class="xfp-stat-item">
                <span class="xfp-stat-value xfp-stat-saved">0</span>
                <span class="xfp-stat-label">Saved</span>
              </div>
            </div>

            <div class="xfp-divider"></div>

            <!-- Button Position -->
            <div class="xfp-setting-row">
              <label class="xfp-setting-label">Button Position</label>
              <div class="xfp-setting-options xfp-positions">
                <button class="xfp-setting-btn" data-pos="bottom-right">↘</button>
                <button class="xfp-setting-btn" data-pos="bottom-left">↙</button>
                <button class="xfp-setting-btn" data-pos="top-right">↗</button>
                <button class="xfp-setting-btn" data-pos="top-left">↖</button>
                <button class="xfp-setting-btn" data-pos="middle-right">→</button>
              </div>
            </div>

            <!-- Hide Button -->
            <div class="xfp-setting-row">
              <label class="xfp-checkbox-row">
                <input type="checkbox" class="xfp-hide-btn-cb">
                <span>Hide floating button</span>
              </label>
            </div>

            <!-- Debug Mode -->
            <div class="xfp-setting-row">
              <label class="xfp-checkbox-row">
                <input type="checkbox" class="xfp-debug-mode-cb">
                <span>Debug mode (console logs)</span>
              </label>
            </div>

            <!-- Clear Data -->
            <div class="xfp-setting-row">
              <button class="xfp-clear-data-btn">Clear stored data</button>
            </div>
          </div>
        </div>
      </div>
      <button class="xfp-floating-btn">
        <span class="xfp-floating-btn-icon">🌴</span>
        <span class="xfp-floating-badge">0</span>
      </button>
    `;

    document.body.appendChild(panel);

    // Toggle dropdown
    const btn = panel.querySelector('.xfp-floating-btn');
    const dropdown = panel.querySelector('.xfp-floating-dropdown');
    const closeBtn = panel.querySelector('.xfp-dropdown-close');

    // Restore dropdown open state from storage
    chrome.storage.local.get('floatingDropdownOpen', (result) => {
      if (result.floatingDropdownOpen) {
        dropdown.classList.add('show');
        updateFloatingPanel();
      }
    });

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isShowing = dropdown.classList.toggle('show');
      chrome.storage.local.set({ floatingDropdownOpen: isShowing });
      if (isShowing) {
        updateFloatingPanel();
      }
    });

    closeBtn.addEventListener('click', () => {
      dropdown.classList.remove('show');
      chrome.storage.local.set({ floatingDropdownOpen: false });
    });

    // Hidden tweets section toggle
    const hiddenToggle = panel.querySelector('.xfp-hidden-toggle');
    const hiddenContent = panel.querySelector('.xfp-hidden-content');

    chrome.storage.local.get('floatingHiddenExpanded', (result) => {
      if (result.floatingHiddenExpanded === false) {
        hiddenToggle.classList.remove('expanded');
        hiddenContent.classList.remove('show');
      }
    });

    hiddenToggle.addEventListener('click', () => {
      hiddenToggle.classList.toggle('expanded');
      hiddenContent.classList.toggle('show');
      chrome.storage.local.set({ floatingHiddenExpanded: hiddenContent.classList.contains('show') });
    });

    // Custom Prompt textarea (auto-saves on blur)
    const promptInput = panel.querySelector('.xfp-prompt-input');
    if (promptInput) {
      // Load current prompt
      promptInput.value = VibeFilter.customPrompt || '';

      // Auto-save on blur
      promptInput.addEventListener('blur', async () => {
        const newPrompt = promptInput.value.trim();
        const valueToSave = newPrompt === '' ? null : newPrompt;
        if (valueToSave !== VibeFilter.customPrompt) {
          VibeFilter.customPrompt = valueToSave;
          await VibeFilter.saveCustomPrompt(valueToSave);
          showToast(valueToSave ? 'Custom prompt saved!' : 'Using default prompt', 'info', 2000);
        }
      });
    }

    // API Key toggle button
    const apiToggleBtn = panel.querySelector('.xfp-api-toggle-btn');
    const apiInput = panel.querySelector('.xfp-api-key-section .xfp-api-input');
    const apiStatus = panel.querySelector('.xfp-api-status');

    if (apiToggleBtn && apiInput) {
      // Load the active provider's key (masked)
      const syncProviderKeyField = async () => {
        const config = await XFPProviders.loadConfig();
        const def = XFPProviders.PROVIDERS[config.primary];
        const name = XFPProviders.displayName(config.primary);
        if (document.activeElement !== apiInput) apiInput.value = config.providers[config.primary].apiKey || '';
        apiInput.placeholder = def.keyPlaceholder || 'API key';
        const nameEl = panel.querySelector('.xfp-api-key-name');
        const linkEl = panel.querySelector('.xfp-api-key-link');
        if (nameEl) nameEl.textContent = `${name} API Key${def.keyOptional ? ' (optional)' : ''}`;
        if (linkEl) {
          linkEl.style.display = def.keyUrl ? '' : 'none';
          if (def.keyUrl) linkEl.href = def.keyUrl;
        }
        if (apiStatus) {
          const status = (await XFPProviders.loadStatuses())[config.primary];
          apiStatus.textContent = XFPProviders.describeStatus(config.providers[config.primary], status).label;
        }
      };
      syncProviderKeyField();
      VibeFilter.watchProviderConfig(syncProviderKeyField);

      apiToggleBtn.addEventListener('click', () => {
        if (apiInput.type === 'password') {
          apiInput.type = 'text';
          apiToggleBtn.textContent = 'Hide';
        } else {
          apiInput.type = 'password';
          apiToggleBtn.textContent = 'Show';
        }
      });

      // Save API key on change
      apiInput.addEventListener('change', async () => {
        const newKey = apiInput.value.trim();
        await VibeFilter.saveActiveProviderKey(newKey);
        initAIScorer();
        if (apiStatus) {
          const name = VibeFilter.provider.primaryName;
          apiStatus.textContent = newKey
            ? `${name} key saved. Use Test connection in the extension popup to verify it.`
            : `Add your ${name} key to enable AI scoring`;
        }
      });
    }

    // Settings section toggle
    const settingsToggle = panel.querySelector('.xfp-settings-toggle');
    const settingsContent = panel.querySelector('.xfp-settings-content');

    chrome.storage.local.get('floatingSettingsExpanded', (result) => {
      if (result.floatingSettingsExpanded) {
        settingsToggle.classList.add('expanded');
        settingsContent.classList.add('show');
      }
    });

    settingsToggle.addEventListener('click', () => {
      settingsToggle.classList.toggle('expanded');
      settingsContent.classList.toggle('show');
      chrome.storage.local.set({ floatingSettingsExpanded: settingsContent.classList.contains('show') });
    });

    // Filter Active checkbox
    const filterActiveCb = panel.querySelector('.xfp-filter-active-cb');
    filterActiveCb.addEventListener('change', () => {
      VibeFilter.settings.enabled = filterActiveCb.checked;
      VibeFilter.saveSettings({ enabled: filterActiveCb.checked });
      reprocessVisibleTweets();
    });

    // Filter mode buttons
    panel.querySelectorAll('.xfp-filter-modes .xfp-setting-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        panel.querySelectorAll('.xfp-filter-modes .xfp-setting-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        VibeFilter.settings.filterMode = btn.dataset.mode;
        VibeFilter.saveSettings({ filterMode: btn.dataset.mode });
        reprocessVisibleTweets();
      });
    });

    // Threshold slider
    const thresholdSlider = panel.querySelector('.xfp-threshold-slider');
    const thresholdValue = panel.querySelector('.xfp-threshold-value');
    thresholdSlider.addEventListener('input', () => {
      thresholdValue.textContent = thresholdSlider.value;
    });
    thresholdSlider.addEventListener('change', () => {
      VibeFilter.settings.threshold = parseInt(thresholdSlider.value);
      VibeFilter.saveSettings({ threshold: parseInt(thresholdSlider.value) });
      reprocessVisibleTweets();
    });

    // Show scores checkbox
    const showScoresCb = panel.querySelector('.xfp-show-scores-cb');
    showScoresCb.addEventListener('change', () => {
      VibeFilter.settings.showScores = showScoresCb.checked;
      VibeFilter.saveSettings({ showScores: showScoresCb.checked });
      reprocessVisibleTweets();
    });

    // Debug mode checkbox
    const debugModeCb = panel.querySelector('.xfp-debug-mode-cb');
    debugModeCb.addEventListener('change', () => {
      VibeFilter.settings.debugMode = debugModeCb.checked;
      VibeFilter.saveSettings({ debugMode: debugModeCb.checked });
      if (debugModeCb.checked) {
        console.log('🌴 XFP Debug mode enabled. API status:', VibeFilter.getApiStatus());
      }
    });

    // Use AI checkbox
    const useAiCb = panel.querySelector('.xfp-use-ai-cb');
    useAiCb.addEventListener('change', () => {
      VibeFilter.settings.useAI = useAiCb.checked;
      VibeFilter.saveSettings({ useAI: useAiCb.checked });
      if (useAiCb.checked && !aiProviderReady) {
        initAIScorer();
      }
      reprocessVisibleTweets();
    });

    // Position buttons
    panel.querySelectorAll('.xfp-positions .xfp-setting-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        panel.querySelectorAll('.xfp-positions .xfp-setting-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        panel.className = `xfp-floating-panel pos-${btn.dataset.pos}`;
        VibeFilter.settings.floatingPosition = btn.dataset.pos;
        VibeFilter.saveSettings({ floatingPosition: btn.dataset.pos });
      });
    });

    // Hide button checkbox
    const hideBtnCb = panel.querySelector('.xfp-hide-btn-cb');
    hideBtnCb.addEventListener('change', () => {
      if (hideBtnCb.checked) {
        panel.classList.add('hidden');
        VibeFilter.settings.floatingHidden = true;
        VibeFilter.saveSettings({ floatingHidden: true });
      }
    });

    // Clear data button
    const clearDataBtn = panel.querySelector('.xfp-clear-data-btn');
    clearDataBtn.addEventListener('click', async () => {
      if (confirm('Clear all stored tweet data?')) {
        await window.tweetDB.clearAll();
        processedTweets.clear();
        hiddenCount = 0;
        hiddenTweets.length = 0;
        updateFloatingPanel();
      }
    });

    // Note: Removed "click outside to close" behavior so dropdown persists during navigation
    // User can close via palm tree button toggle or X button

    return panel;
  }

  // Update floating panel content
  async function updateFloatingPanel() {
    const panel = document.querySelector('.xfp-floating-panel');
    if (!panel) return;

    const badge = panel.querySelector('.xfp-floating-badge');
    const list = panel.querySelector('.xfp-dropdown-list');
    const aiDot = panel.querySelector('.xfp-ai-dot');
    const aiText = panel.querySelector('.xfp-ai-text');
    const hiddenCountLabel = panel.querySelector('.xfp-hidden-count-label');

    // Update badge and hidden count label
    if (badge) {
      badge.textContent = hiddenCount;
      badge.style.display = hiddenCount > 0 ? 'flex' : 'none';
    }
    if (hiddenCountLabel) {
      hiddenCountLabel.textContent = `(${hiddenCount})`;
    }

    // Update AI status (active provider and optional fallback)
    if (aiDot && aiText) {
      const p = VibeFilter.provider;
      if (VibeFilter.settings.useAI === false) {
        aiDot.classList.remove('ready');
        aiText.textContent = 'AI disabled';
      } else if (VibeFilter.hasAI()) {
        aiDot.classList.add('ready');
        const lead = p.primaryConfigured ? `${p.primaryName} configured` : `${p.fallbackName} configured`;
        aiText.textContent = p.primaryConfigured && p.fallbackName ? `${lead} · fallback ${p.fallbackName}` : lead;
      } else if (p.configured) {
        aiDot.classList.remove('ready');
        aiText.textContent = 'AI unavailable · keywords for now';
      } else {
        aiDot.classList.remove('ready');
        aiText.textContent = `Keywords only · add your ${p.primaryName} key`;
      }
    }

    // Update hidden tweets list
    if (list) {
      if (hiddenTweets.length === 0) {
        list.innerHTML = '<div class="xfp-dropdown-empty">No tweets hidden yet</div>';
      } else {
        list.innerHTML = hiddenTweets.slice(0, 20).map(tweet => `
          <div class="xfp-dropdown-item" data-url="${tweet.url}">
            <div class="xfp-dropdown-author">@${tweet.authorHandle}</div>
            <div class="xfp-dropdown-text">${escapeHtml(tweet.text)}</div>
            <div class="xfp-dropdown-meta">
              <span>${tweet.vibeLabel}</span>
              <span>Score: ${tweet.score}</span>
            </div>
          </div>
        `).join('');

        // Add click handlers
        list.querySelectorAll('.xfp-dropdown-item').forEach(item => {
          item.addEventListener('click', () => {
            window.open(item.dataset.url, '_blank');
          });
        });
      }
    }

    // Update filter active checkbox
    const filterActiveCb = panel.querySelector('.xfp-filter-active-cb');
    if (filterActiveCb) {
      filterActiveCb.checked = VibeFilter.settings.enabled !== false;
    }

    // Update filter mode buttons
    const filterMode = VibeFilter.settings.filterMode || 'hide';
    panel.querySelectorAll('.xfp-filter-modes .xfp-setting-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.mode === filterMode);
    });

    // Update threshold slider
    const thresholdSlider = panel.querySelector('.xfp-threshold-slider');
    const thresholdValue = panel.querySelector('.xfp-threshold-value');
    if (thresholdSlider && thresholdValue) {
      thresholdSlider.value = VibeFilter.settings.threshold || 0;
      thresholdValue.textContent = VibeFilter.settings.threshold || 0;
    }

    // Update show scores checkbox
    const showScoresCb = panel.querySelector('.xfp-show-scores-cb');
    if (showScoresCb) {
      showScoresCb.checked = VibeFilter.settings.showScores || false;
    }

    // Update debug mode checkbox
    const debugModeCb = panel.querySelector('.xfp-debug-mode-cb');
    if (debugModeCb) {
      debugModeCb.checked = VibeFilter.settings.debugMode || false;
    }

    // Update use AI checkbox
    const useAiCb = panel.querySelector('.xfp-use-ai-cb');
    if (useAiCb) {
      useAiCb.checked = VibeFilter.settings.useAI !== false;
    }

    // Update position buttons
    const position = VibeFilter.settings.floatingPosition || 'bottom-right';
    panel.querySelectorAll('.xfp-positions .xfp-setting-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.pos === position);
    });

    // Update stats
    try {
      const stats = await window.tweetDB.getStats();
      const statHidden = panel.querySelector('.xfp-stat-hidden');
      const statProcessed = panel.querySelector('.xfp-stat-processed');
      const statSaved = panel.querySelector('.xfp-stat-saved');

      if (statHidden) statHidden.textContent = hiddenCount;
      if (statProcessed) statProcessed.textContent = processedTweets.size;
      if (statSaved) statSaved.textContent = stats?.tweetCount || 0;
    } catch (error) {
      console.warn('Could not update stats:', error);
    }
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
  }

  // Create "Load More" button at bottom of feed
  async function createLoadMoreButton() {
    // Remove existing if any
    document.querySelector('.xfp-load-more-container')?.remove();

    const container = document.createElement('div');
    container.className = 'xfp-load-more-container';

    // Check if button should be hidden (from storage)
    const result = await chrome.storage.sync.get('xfp_load_more_enabled');
    const isEnabled = result.xfp_load_more_enabled !== false; // Default ON
    if (!isEnabled) {
      container.classList.add('hidden');
    }

    container.innerHTML = `
      <button class="xfp-load-more-btn">
        <span class="icon">🌴</span>
        <span class="text">Load More</span>
      </button>
    `;

    const btn = container.querySelector('.xfp-load-more-btn');
    btn.addEventListener('click', async () => {
      if (btn.classList.contains('loading')) return;

      btn.classList.add('loading');
      btn.querySelector('.text').textContent = 'Loading...';
      btn.querySelector('.icon').innerHTML = '<div class="xfp-load-more-spinner"></div>';

      // Scroll down to trigger Twitter's infinite scroll
      const scrollAmount = window.innerHeight * 2;
      window.scrollBy({ top: scrollAmount, behavior: 'smooth' });

      // Wait for new content to load
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Reset button state
      btn.classList.remove('loading');
      btn.querySelector('.text').textContent = 'Load More';
      btn.querySelector('.icon').innerHTML = '🌴';

      // Re-position the button at the new bottom
      positionLoadMoreButton();
    });

    return container;
  }

  // Position the Load More button at the bottom of the timeline
  function positionLoadMoreButton() {
    const container = document.querySelector('.xfp-load-more-container');
    if (!container) return;

    // Find the timeline container
    const timeline = document.querySelector('[data-testid="primaryColumn"] section[role="region"]');
    if (!timeline) return;

    // Move to end of timeline if not already there
    const lastChild = timeline.lastElementChild;
    if (lastChild !== container) {
      timeline.appendChild(container);
    }
  }

  // Initialize Load More button
  let loadMoreContainer = null;
  (async () => {
    loadMoreContainer = await createLoadMoreButton();

    // Observe for timeline to appear and position button
    const timelineObserver = new MutationObserver(() => {
      const timeline = document.querySelector('[data-testid="primaryColumn"] section[role="region"]');
      if (timeline && loadMoreContainer && !timeline.querySelector('.xfp-load-more-container')) {
        timeline.appendChild(loadMoreContainer);
      }
    });
    timelineObserver.observe(document.body, { childList: true, subtree: true });

    // Also try to add immediately
    const timeline = document.querySelector('[data-testid="primaryColumn"] section[role="region"]');
    if (timeline && loadMoreContainer) {
      timeline.appendChild(loadMoreContainer);
    }
  })();

  // Create the floating panel
  const floatingPanel = createFloatingPanel();

  // Update badge whenever hidden count changes (called from applyFilter)
  const originalHiddenCount = { value: 0 };
  setInterval(() => {
    if (originalHiddenCount.value !== hiddenCount) {
      originalHiddenCount.value = hiddenCount;
      updateFloatingPanel();
    }
  }, 500);

  // Initialize - IntersectionObserver handles fast scrolling, no polling needed
  console.log('🌴 XFeed Paradise: Starting tweet observation (dual observer mode)...');
  processVisibleTweets();
  observeTweets();

  // Log stats periodically
  setInterval(async () => {
    const stats = await window.tweetDB.getStats();
    console.log(`🌴 XFeed Paradise: ${stats.tweetCount} tweets collected, ${processedTweets.size} processed this session`);
  }, 60000);

  console.log('🌴 XFeed Paradise: Active and filtering your feed!');
})();
